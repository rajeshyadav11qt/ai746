package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Page1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession hs = request.getSession(true);
        if (hs.isNew()) {
            String name = request.getParameter("txtName");
            hs.setAttribute("uname", name);
            hs.setAttribute("visit", "1");
        } else {
            int visit = Integer.parseInt((String) hs.getAttribute("visit")) + 1;
            out.println("You Visited " + visit + "Times");
            hs.setAttribute("visit", "" + visit);
        }
        out.println("Your Session ID " + hs.getId());
        out.println("You Logged in at  " + new java.util.Date(hs.getCreationTime()));
        out.println("<h3><a href=Page2>Click for Page 2 </a></h3>");
        out.println("<h3><a href=LogoutServlet>Click to logout </a></h3>");
    }
}