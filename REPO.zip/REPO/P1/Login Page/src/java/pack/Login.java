package pack;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet {

     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                PrintWriter out = response.getWriter();
                String n1 = request.getParameter("txt1");
                String n2 = request.getParameter("txt2");
                    
                if(n1.equals("abc") && (n2.equals("abc123"))){
                     out.println("WELCOME " +n1);
                }
                else
                {
                    out.println("INCORRECT USERNAME AND PASSWORD ");
                }
       
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
