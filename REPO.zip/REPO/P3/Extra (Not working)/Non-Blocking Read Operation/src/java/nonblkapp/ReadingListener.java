package nonblkapp;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.AsyncContext;
import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
public class ReadingListener implements ReadListener
{
 private ServletInputStream input = null;
 private AsyncContext ac = null;
 ReadingListener(ServletInputStream in, AsyncContext c) {
 input = in;
 ac = c;
 }
 @Override
 public void onDataAvailable() throws IOException {
 }
 public void onAllDataRead() throws IOException {
 ac.complete();
 }
 public void onError(final Throwable t) {
 ac.complete();
 t.printStackTrace();
 }
}
