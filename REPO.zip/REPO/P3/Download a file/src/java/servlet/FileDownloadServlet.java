package servlet;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "FileDownloadServlet", urlPatterns = {"/FileDownloadServlet"})
public class FileDownloadServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fileToDownload = request.getParameter("filename");
        System.err.println("Downloading file now...");
        downloadFile(request, response, fileToDownload);
    }
    
    

  private void downloadFile(HttpServletRequest request, HttpServletResponse response, String fileName) throws ServletException, IOException {
        int lenght = 0;
        try (ServletOutputStream outputStream = response.getOutputStream()) {
            ServletContext context = getServletConfig().getServletContext();
            response.setContentType((context.getMimeType(fileName) != null) ? context.getMimeType(fileName) : "application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName);
            InputStream inputStream = context.getResourceAsStream("/" + fileName);
            byte[] bytes = new byte[1024];
            
            while((inputStream != null) && ((lenght = inputStream.read(bytes)) != -1)) {
                outputStream.write(bytes, 0, lenght);
            }
            outputStream.flush();
        }
    }
}
