package mypack;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Page2 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession hs = request.getSession(false);
        out.println("<h3>Welcome Again on Page No. 2</h3>");
        int visit = Integer.parseInt((String) hs.getAttribute("visit")) + 1;
        out.println("<h3>You Visited " + visit + "Times</h3>");
        hs.setAttribute("visit", "" + visit);

        out.println("Your Session ID " + hs.getId());
        out.println("You Logged in at  " + new java.util.Date(hs.getCreationTime()));
        out.println("<h3><a href=Page1>Click for Page 1 </a></h3>");
        out.println("<h3><a href=LogoutServlet>Click to logout </a></h3>");
    }
}
